#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QWebView>
#include <QWebHistory>
#include <QPlastiqueStyle>
#include <QShortcut>
#include <qdebug.h>

MainWindow::MainWindow(QWidget *parent)
        : QMainWindow(parent), ui(new Ui::MainWindowClass)
{
    ui->setupUi(this);
	setWindowTitle("CuteQt");
    QWebSettings::globalSettings()->setAttribute(QWebSettings::PluginsEnabled, true);

    connect(ui->tabWidget, SIGNAL(tabCloseRequested(int)), this, SLOT(closeTab(int)));
    newTabButton = new QToolButton(this);
    newTabButton->setStyleSheet(
            "QToolButton{border-image: url(:/images/newtab.png); border:2px;}"
            "QToolButton:hover{border-image: url(:/images/newtab_hover.png);}"
            "QToolButton:pressed{border-image: url(:/images/newtab_pressed.png);}"
            );
    ui->tabWidget->setCornerWidget(newTabButton, Qt::TopRightCorner);
    newTabButton->setFixedSize(QSize(26, 16));

    connect(newTabButton, SIGNAL(clicked()), this, SLOT(newTab()));
    connect(ui->addressLine, SIGNAL(returnPressed()), this, SLOT(openUrl()));
    connect(ui->searchEdit, SIGNAL(returnPressed()), this, SLOT(openSearch()));
    connect(ui->tabWidget, SIGNAL(currentChanged(int)), this, SLOT(updateAddressbar()));
    connect(ui->backButton, SIGNAL(clicked()), this, SLOT(back()));
    connect(ui->forwardButton, SIGNAL(clicked()), this, SLOT(forward()));
    connect(ui->reloadButton, SIGNAL(clicked()), this, SLOT(reload()));

    ui->tabWidget->removeTab(0);
    newTab("http://www.cuteqt.com/");

    updateButtons();

    QShortcut *locationShortcut = new QShortcut(QKeySequence("Ctrl+L"), this);
    QShortcut *fullScreenShortcut = new QShortcut(QKeySequence("F11"), this);
    connect(locationShortcut , SIGNAL(activated()), this , SLOT(location()));
    connect(fullScreenShortcut , SIGNAL(activated()), this , SLOT(toggleFullScreen()));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::openUrl()
{
    if (ui->tabWidget->count() == 0)
        newTab();

    QWebView *view = qobject_cast<QWebView*>(ui->tabWidget->currentWidget());
    if (view) {
        QString address = ui->addressLine->text();
        if (!address.startsWith("http://")) {
            address.prepend("http://");
            ui->addressLine->setText(address);
        }
        view->setUrl(address);
        ui->tabWidget->setTabText(ui->tabWidget->currentIndex(), address);
    }
}

void MainWindow::openSearch()
{
    if (ui->tabWidget->count() == 0)
        newTab();

    QWebView *view = qobject_cast<QWebView*>(ui->tabWidget->currentWidget());
    if (view) {
        QString address = "www.google.no/search?q="+ QUrl::toPercentEncoding(ui->searchEdit->text());
        ui->tabWidget->setTabText(ui->tabWidget->currentIndex(), address);
        view->setUrl("http://" + address);
    }
}

void MainWindow::closeTab(int tab)
{
    QWidget *widget = ui->tabWidget->widget(tab);
    if (widget) {
        ui->tabWidget->removeTab(ui->tabWidget->indexOf(widget));
        delete widget;
    }
}

void MainWindow::updateButtons()
{
    QWebView *view = qobject_cast<QWebView*>(ui->tabWidget->currentWidget());
    if (view) {
        ui->backButton->setEnabled(view->history()->canGoBack());
        ui->forwardButton->setEnabled(view->history()->canGoForward());
    }
}

void MainWindow::back()
{
    QWebView *view = qobject_cast<QWebView*>(ui->tabWidget->currentWidget());
    if (view)
        view->back();
}

void MainWindow::forward()
{
    QWebView *view = qobject_cast<QWebView*>(ui->tabWidget->currentWidget());
    if (view)
        view->forward();
}

void MainWindow::newTab()
{
    newTab("http://www.cuteqt.com/bbs/");
}

void MainWindow::newTab(const QString &url)
{
    QWebView *view = new QWebView(this);
    connect(view, SIGNAL(urlChanged(QUrl)), this, SLOT(updateAddressbar()));
    connect(view, SIGNAL(loadStarted()), this, SLOT(handleLoadStarted()));
    connect(view, SIGNAL(loadFinished(bool)), this, SLOT(handleLoadFinished()));

    ui->tabWidget->addTab(view, url);
    view->setUrl(url);
}


void MainWindow::reload()
{
    QWebView *view = qobject_cast<QWebView*>(ui->tabWidget->currentWidget());
    if (view)
        view->reload();
}

void MainWindow::updateAddressbar()
{
    QWebView *view = qobject_cast<QWebView*>(ui->tabWidget->currentWidget());
    if (view) {
        QString address = view->url().toString();
        ui->addressLine->setText(address);
        ui->tabWidget->setTabText(ui->tabWidget->currentIndex(), address);
        updateButtons();
    }
}

void MainWindow::handleLoadFinished()
{
    QWebView *view = qobject_cast<QWebView*>(ui->tabWidget->currentWidget());
    if (view)
        view->setCursor(QCursor());
}

void MainWindow::handleLoadStarted()
{
    QWebView *view = qobject_cast<QWebView*>(ui->tabWidget->currentWidget());
    if (view)
        view->setCursor(QCursor(Qt::BusyCursor));
}

void MainWindow::location()
{
    ui->addressLine->selectAll();
    ui->addressLine->setFocus();
}

void MainWindow::toggleFullScreen()
{
    if (isFullScreen())
        showNormal();
    else
        showFullScreen();
}

#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QtGui/QMainWindow>
#include <QtCore/QUrl>
class QToolButton;

namespace Ui{
    class MainWindowClass;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT
public:

    MainWindow(QWidget *parent = 0);
    ~MainWindow();

    void newTab(const QString &url);

public slots:
    void closeTab(int);
    void newTab();
    void openUrl();
    void openSearch();
    void reload();
    void updateAddressbar();
    void location();
    void back();
    void forward();
    void updateButtons();
    void handleLoadStarted();
    void handleLoadFinished();
    void toggleFullScreen();

private:
    Ui::MainWindowClass *ui;
    QToolButton *newTabButton;
};

#endif // MAINWINDOW_H

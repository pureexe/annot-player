/****************************************************************************
**
** Copyright (C) 2009 Nokia Corporation and/or its subsidiary(-ies).
**
** Use, modification and distribution is allowed without limitation,
** warranty, liability or support of any kind.
**
****************************************************************************/

#include <QtGui/QApplication>
#include "mainwindow.h"

#include "qtwin.h"

#include <QtGui>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow window;
#ifdef Q_WS_X11
    window.setAttribute(Qt::WA_TranslucentBackground);
    window.setAttribute(Qt::WA_NoSystemBackground, false);
    QPalette pal = window.palette();
    QColor bg = pal.window().color();
    bg.setAlpha(180);
    pal.setColor(QPalette::Window, bg);
    window.setPalette(pal);
    window.ensurePolished(); // workaround Oxygen filling the background
    window.setAttribute(Qt::WA_StyledBackground, false);
#endif
    if (QtWin::isCompositionEnabled()) {
        QtWin::extendFrameIntoClientArea(&window);
        window.setContentsMargins(0, 0, 0, 0);
    }
    window.show();
    return a.exec();
}
